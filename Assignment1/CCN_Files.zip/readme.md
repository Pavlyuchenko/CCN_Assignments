# README

This repository contains three important files:

1. ga_hello_world.py - This contains all the code for you to try,
2. GA_HELLO_WORLD.ipynb - This is a Jupyter notebook that also contains explanations, statistics and graphs. You can also find my student number there.
3. Report.pdf - The Jupyter Notebook converted to PDF format for easier reading.
